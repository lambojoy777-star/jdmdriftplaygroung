JDM DRIFT PLAYGROUND — Hosting Instructions
==============================================

Structure:
- /index.html   → Redirects to /en/index.html
- /en/index.html → English page
- /jp/index.html → Japanese page
- /404.html     → Not found (for GitHub Pages/Netlify)

Option A: GitHub Pages (Free)
-----------------------------
1) Create a new repo on GitHub (e.g., jdmdriftplayground).
2) Upload *all files and folders* from this ZIP (keep /en and /jp folders).
3) In repo Settings → Pages:
   - Source: "Deploy from a branch"
   - Branch: main (or master) / root
4) Visit: https://<your-username>.github.io/<repo-name>/
   - The root will redirect to /en/. Japanese page is /jp/index.html.
5) Optional: Add your custom domain in the same Pages screen (set A/ALIAS records).

Option B: Netlify (Very Easy)
-----------------------------
1) Go to https://app.netlify.com/ and drag & drop this folder.
2) Netlify will give you a URL like https://something.netlify.app
3) Add a custom domain in Netlify → Domain management.
4) If using a custom domain, add a CNAME record to your Netlify URL.

Option C: Vercel
----------------
1) Go to https://vercel.com/ → "Add New Project" → "Deploy" → drag this folder.
2) Set your domain in Vercel (DNS → CNAME to cname.vercel-dns.com).

Option D: cPanel/Shared Hosting
-------------------------------
1) Upload everything to your site's document root (public_html).
2) Ensure the /en and /jp folders are intact.
3) Visiting your domain will redirect to /en/index.html.

SEO Tip
-------
If you add a custom domain, you can set /en as default language and link rel="alternate" hreflang tags later if needed.

Contact Links
-------------
Update booking email/WhatsApp in the HTML if you want real contact info:
- Search for "booking@jdmdriftplayground.com" and replace
- Search for "wa.me/00000000000" and replace

Build date: 2025-10-21 04:02 
